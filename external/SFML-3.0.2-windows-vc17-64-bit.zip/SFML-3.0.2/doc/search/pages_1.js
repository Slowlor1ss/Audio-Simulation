var searchData=
[
  ['example_0',['Short example',['../index.html#example',1,'']]]
];
