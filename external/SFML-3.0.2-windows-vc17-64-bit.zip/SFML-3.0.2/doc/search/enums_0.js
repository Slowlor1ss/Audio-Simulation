var searchData=
[
  ['attribute_0',['Attribute',['../structsf_1_1ContextSettings.html#af2e91e57e8d26c40afe2ec8efaa32a2c',1,'sf::ContextSettings']]],
  ['axis_1',['Axis',['../namespacesf_1_1Joystick.html#a48db337092c2e263774f94de6d50baa7',1,'sf::Joystick']]]
];
