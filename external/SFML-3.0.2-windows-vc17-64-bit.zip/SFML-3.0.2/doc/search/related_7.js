var searchData=
[
  ['window_0',['Window',['../classsf_1_1WindowBase.html#a553f958a25683445088050a69d3de8e9',1,'sf::WindowBase']]],
  ['windowbase_1',['WindowBase',['../classsf_1_1Cursor.html#a041a37646cfea08c96a1a656c37e84f4',1,'sf::Cursor::WindowBase()'],['../classsf_1_1Event.html#a041a37646cfea08c96a1a656c37e84f4',1,'sf::Event::WindowBase()']]]
];
