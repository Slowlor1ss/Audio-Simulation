var searchData=
[
  ['keypressed_0',['KeyPressed',['../structsf_1_1Event_1_1KeyPressed.html',1,'sf::Event']]],
  ['keyreleased_1',['KeyReleased',['../structsf_1_1Event_1_1KeyReleased.html',1,'sf::Event']]]
];
